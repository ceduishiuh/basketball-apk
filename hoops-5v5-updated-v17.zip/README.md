# Hoops 5v5 — Offline Android APK Project

This Android Gradle project wraps your HTML5 game (`app/src/main/assets/index.html`) inside a hardware-accelerated, 100% offline Android `WebView` using `WebViewAssetLoader`.

- **Application ID:** `com.hoops5v5.offline`
- **Version:** `1.0.0` (code `1`)
- **Orientation:** `sensorLandscape`
- **Permissions:** None (`INTERNET` permission is omitted for pure offline execution)
- **Local Saves:** `localStorage` is enabled via `domStorageEnabled = true`

---

## Option 1: Build APK Online via GitHub Actions (No Android Studio Needed)

1. Create a new repository on GitHub (private or public).
2. Upload all files from this extracted folder to the repository (make sure `.github/workflows/build-apk.yml` is included).
3. Open the **Actions** tab in your GitHub repository.
4. Click the **Build Offline Android APK** workflow run (it starts automatically on push, or click **Run workflow**).
5. Once finished (~2 minutes), download **hoops-5v5-offline-apk** from the **Artifacts** section and install `app-debug.apk` on your Android phone.

---

## Option 2: Build APK Locally with Android Studio

1. Open **Android Studio** and choose **File > Open...**, then select this extracted folder.
2. Wait for Gradle Sync to finish.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your installable APK will be saved at:
   `app/build/outputs/apk/debug/app-debug.apk`

For a Play Store signed release build, use **Build > Generate Signed Bundle / APK...**.


## Tournament update
- Round banner in-game (top): FIRST ROUND / QUARTERFINALS / SEMIFINALS / FINALS, game number, and series status (leads / tied / elimination).
- Round name painted in the middle of the court during tournament games.
- Player portraits (top half body) in tournament Stats (leaders + table) and box scores.
- Box scores for every game (played, watched or simmed), Player of the Game for the winning team, and series stats (per game / totals) + series MVP. Open from the bracket with the 📋 button or from the post-game "Series Stats" button.
- Awards tab (🏅): live MVP / Defensive POY / 6th Man / Clutch race that updates after every game day (▲▼ movement), plus All-Tournament and All-Defensive 1st/2nd/3rd teams (PG, SG, SF, PF, C).

---

## Changes in this version

- **Player profile** – tap any player (avatar or name) in the tournament, stats, awards, box scores, offseason tables or the roster editor (PROFILE button). Shows icon, name, position, team, jersey #, ratings, contract, game log, stats per round vs. each opponent, achievements and team history.
- **Offseason TRANSFERS tab** – every move per day (Day 1–5 + Lock): `Player · POS · OVR · Old team → New team`, `Old team → Released`, `FA → New team`, plus re-signings. Filters by day, type and your team.
- **AI teams now trade players** directly during offseason days.
- **Roster Reveal** – after the roster lock, proceed to a team-by-team reveal (Starting five PG–C + bench). Newly arrived players are tagged **NEW**. Then start the next season.
- **New free agents every offseason** – a fresh generated class on day 1 plus new ones each day (tagged NEW FA in the market).

## Update: Tournament progression & profile
- Player profile: nationality (flag), Games Started (GS), seasons played, games played, last-offseason rating change.
- Every new tournament season players improve or slump; 32+ mostly regress, but ~18% "age gracefully" (slow decline) and ~18% decline early. Breakout / slump years can happen at any age.
- Auto-generated rosters (and new free agents) now have only ~10% players aged 30+.
