# Hoops 5v5 — Offline Android APK Project

This Android Gradle project wraps your HTML5 game (`app/src/main/assets/index.html`) inside a hardware-accelerated, 100% offline Android `WebView` using `WebViewAssetLoader`.

- **Application ID:** `com.hoops5v5.offline`
- **Version:** `1.0.0` (code `1`)
- **Orientation:** `sensorLandscape`
- **Permissions:** None (`INTERNET` permission is omitted for pure offline execution)
- **Local Saves:** `localStorage` is enabled via `domStorageEnabled = true`

---

## Option 1: Build APK Online via GitHub Actions (No Android Studio Needed)

1. Create a new repository on GitHub (private or public).
2. Upload all files from this extracted folder to the repository (make sure `.github/workflows/build-apk.yml` is included).
3. Open the **Actions** tab in your GitHub repository.
4. Click the **Build Offline Android APK** workflow run (it starts automatically on push, or click **Run workflow**).
5. Once finished (~2 minutes), download **hoops-5v5-offline-apk** from the **Artifacts** section and install `app-debug.apk` on your Android phone.

---

## Option 2: Build APK Locally with Android Studio

1. Open **Android Studio** and choose **File > Open...**, then select this extracted folder.
2. Wait for Gradle Sync to finish.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your installable APK will be saved at:
   `app/build/outputs/apk/debug/app-debug.apk`

For a Play Store signed release build, use **Build > Generate Signed Bundle / APK...**.
